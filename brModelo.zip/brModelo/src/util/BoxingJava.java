/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

/**
 *
 * @author ccandido
 */
public class BoxingJava {

    public BoxingJava() {
        super();
    }

    public BoxingJava(String txt) {
        super();
        Str = txt;
    }

    public BoxingJava(int i) {
        super();
        Int = i;
    }

    public BoxingJava(boolean vf) {
        super();
        SN = vf;
    }
    
    public String Str = "";
    public int Int = 0;
    public boolean SN = false;
    
}
