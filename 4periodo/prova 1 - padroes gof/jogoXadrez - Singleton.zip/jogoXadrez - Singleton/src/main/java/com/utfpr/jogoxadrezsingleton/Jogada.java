package com.utfpr.jogoxadrezsingleton;

public interface Jogada {
    void moverPeca(String nomeJogador, String peca);
}
