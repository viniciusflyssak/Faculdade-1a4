package com.utfpr.exercicio_revisao;

import java.sql.*;
import java.util.Scanner;

public class App{
    public static Statement st;
    
    public static void queryExec(String query){
        try{
            st.executeUpdate(query); //Executar a query
        }catch(SQLException e){
            System.out.println("Erro: " + e.getMessage());
        }
    };
    
    public static ResultSet queryExecSelect(String query){
        try{
            return st.executeQuery(query); //Executar a query
        }catch(SQLException e){
            System.out.println("Erro: " + e.getMessage());
        }
        return null;
    };
    
    public static void criarTabelas(){   
        String query = " create table profissionais(id_profissional serial primary key, "
                + " nome varchar(255) constraint nnnome not null, "
                + " profissao varchar(255) constraint nnprofissao not null, "
                + " cpf varchar(20) constraint nncpf not null, "
                + " sexo varchar(1) constraint nnsexo not null) ";
        queryExec(query); //Executar a query
        
        query = " create table animais (id_animal serial primary key, "
                + " nome varchar(255) constraint nnnome not null, "
                + " especie varchar(255), "
                + " id_profissional integer constraint animais_profissionais references profissionais(id_profissional)) ";
        queryExec(query); //Executar a query    

        query = " create table servicos(id_servico serial primary key, "
                + " nome varchar (100) constraint nnnome not null, "
                + " descricao varchar (255), "
                + " data_servico timestamp constraint nndata_servico not null, "
                + " id_profissional integer, "
                + " id_animal integer, "
                + " concluido bool,"
                + " constraint servicos_profissionais foreign key (id_profissional) references profissionais(id_profissional),"
                + " constraint servicos_animais foreign key (id_animal) references animais(id_animal));  ";
        queryExec(query);
        System.out.println("Tabelas criadas!");
    };
    
    public static void cadastrarAnimal(){   
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o nome do animal:");
        String nome = scanner.nextLine();
        System.out.println("Digite a espécie do animal:");
        String especie = scanner.nextLine();
        System.out.println("Digite o cuidador do animal(se não houver, digite 0):");
        int profissional = scanner.nextInt();
        String query = " insert into animais values (default, '"+nome+"', '"+especie+"', NULLIF("+profissional+", 0) ) ";
        queryExec(query); //Executar a query        
        System.out.println("Animal cadastrado com sucesso!");
    };
    
    public static void cadastrarFuncionario(){  
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o nome do funcionário:");
        String nome = scanner.nextLine();
        System.out.println("Digite a profissão:");
        String profissao = scanner.nextLine();
        System.out.println("Digite o cpf do funcionário:");
        String cpf = scanner.nextLine();
        System.out.println("Informe o sexo: F para feminino, M para masculino ou O para outro");
        String sexo = scanner.nextLine();
        String query = " insert into profissionais values (default, '"+nome+"', '"+profissao+"', '"+cpf+"', '"+sexo+"' ) ";
        queryExec(query); //Executar a query
        System.out.println("Funcionário cadastrado com sucesso!");
    };
    
    public static void cadastrarServico(){  
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o nome do Serviço:");
        String nome = scanner.nextLine();
        System.out.println("Digite a descrição:");
        String descricao = scanner.nextLine();
        System.out.println("Digite a data do servíço(AAAA-MM-DD HH:MM):");
        String data = scanner.nextLine();
        System.out.println("Informe o código do profissional responsável:");
        int profissional = scanner.nextInt();
        System.out.println("Informe o código do animal:");
        int animal = scanner.nextInt();
        String query = " insert into servicos values (default, '"+nome+"', '"+descricao+"', '"+data+"', "+profissional+", "+animal+", false ) ";
        queryExec(query); //Executar a query
        System.out.println("Serviço cadastrado com sucesso!");
    };
    
    public static void listarServicos(){ 
        try {
            ResultSet rs = queryExecSelect("select * from servicos");
            while (rs.next()) {
                System.out.println(rs.getString("id_servico") + " - " + rs.getString("nome") + " - " + rs.getString("descricao"));
            }   
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    };
    
    public static void consultarServico(){ 
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o código do serviço:");
        int codigo = scanner.nextInt();
        try {
            ResultSet rs = queryExecSelect(" select s.id_servico, s.nome as  nome_servico, p.nome as nome_profissional, a.nome as nome_animal, s.descricao, s.data_servico  from servicos s"
                                         + " inner join profissionais p on p.id_profissional = s.id_profissional"
                                         + " inner join animais a on a.id_animal = s.id_animal "
                                         + " where id_servico = " + codigo);
            while (rs.next()) {
                System.out.println("Código: " + rs.getString("id_servico"));
                System.out.println("Nome: " + rs.getString("nome_servico"));
                System.out.println("Descrição: " + rs.getString("descricao"));
                System.out.println("Data: " + rs.getString("data_servico"));
                System.out.println("Profissional: " + rs.getString("nome_profissional"));
                System.out.println("Animal: " + rs.getString("nome_animal"));
            }   
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    };
    
    public static void consultaProfissional(){ 
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o código do funcionário: ");
        int codigo = scanner.nextInt();
        try {
            ResultSet rs = queryExecSelect(" select * from profissionais "
                                         + " where id_profissional = " + codigo);
            while (rs.next()) {
                System.out.println("Código: " + rs.getString("id_profissional"));
                System.out.println("Nome: " + rs.getString("nome"));
                System.out.println("Profissão: " + rs.getString("profissao"));
                System.out.println("CPF: " + rs.getString("cpf"));
                System.out.println("Sexo: " + rs.getString("sexo"));
            }   
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    };
    
        public static void consultaAnimal(){ 
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o código do animal: ");
        int codigo = scanner.nextInt();
        try {
            ResultSet rs = queryExecSelect(" select a.id_animal, a.nome as nome_animal, a.especie, p.nome as nome_profissional from animais a "
                                         + " left join profissionais p on p.id_profissional = a.id_profissional  "
                                         + " where a.id_animal = " + codigo);
            while (rs.next()) {
                System.out.println("Código: " + rs.getString("id_animal"));
                System.out.println("Nome: " + rs.getString("nome_animal"));
                System.out.println("Espécie: " + rs.getString("especie"));
                System.out.println("Profissional: " + rs.getString("nome_profissional"));
            }   } catch (SQLException ex) {
                ex.printStackTrace();
        }
    };
    
    public static void main(String[] args)throws SQLException, ClassNotFoundException {
        //variáveis de conexão    
        String driverClassName = "org.postgresql.Driver";
        String url = "jdbc:postgresql://localhost:5432/postgres";
        String user = "postgres";
        String password = "9981";
        int opcao = -1;     
        Scanner scanner = new Scanner(System.in);        
        //carregar o drive
        Class.forName(driverClassName);   
        //abrir conexao
        Connection conn = DriverManager.getConnection(url, user, password);
        //obter Statement
        st = conn.createStatement();
        
        while (opcao != 0) {
            System.out.println("Bem vindo ao gerenciador de zoológicos 2000!");
            System.out.println("Selecione a opção desejada:");
            System.out.println("1 - Criar tabelas");
            System.out.println("2 - Cadastrar funcionário");
            System.out.println("3 - Cadastrar animal");
            System.out.println("4 - Cadastrar serviço");
            System.out.println("5 - Consultar animais");
            System.out.println("6 - Consultar funcionários");
            System.out.println("7 - Consultar serviços");
            System.out.println("8 - Listar serviços");
            opcao = scanner.nextInt();
            switch(opcao){
                case 1 -> criarTabelas();
                case 2 -> cadastrarFuncionario();
                case 3 -> cadastrarAnimal();
                case 4 -> cadastrarServico();
                case 5 -> consultaAnimal();
                case 6 -> consultaProfissional();
                case 7 -> consultarServico();
                case 8 -> listarServicos();
            }
        }
                                     
        //fechar conexao
        conn.close();                
    }    
}