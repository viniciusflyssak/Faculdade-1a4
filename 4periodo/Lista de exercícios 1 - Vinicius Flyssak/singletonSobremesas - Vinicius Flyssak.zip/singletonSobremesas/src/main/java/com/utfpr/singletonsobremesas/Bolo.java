package com.utfpr.singletonsobremesas;

public class Bolo extends Sobremesa {
    public Bolo() {
        valor = 20;
    }
}
    
