package com.utfpr.singletonsobremesas;

public class Sorvete extends Sobremesa {
    public Sorvete() {
        valor = 10;
    }
}
    
