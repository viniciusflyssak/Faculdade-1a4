package com.utfpr.singletonsobremesas;

public class Pudim extends Sobremesa {
    public Pudim() {
        valor = 15;
    }
}
    
