package com.utfpr.bridgecelulares;

public class Samsung implements IDispositivo{

    @Override
    public void configuraCelular() {
        System.out.println("Captura via celular Samsung");
    }
    
}
