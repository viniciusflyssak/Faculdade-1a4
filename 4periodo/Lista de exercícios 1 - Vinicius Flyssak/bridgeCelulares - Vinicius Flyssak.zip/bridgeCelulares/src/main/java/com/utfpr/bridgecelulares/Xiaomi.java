package com.utfpr.bridgecelulares;

public class Xiaomi implements IDispositivo{

    @Override
    public void configuraCelular() {
        System.out.println("Captura via celular Xiaomi");
    }
    
}
