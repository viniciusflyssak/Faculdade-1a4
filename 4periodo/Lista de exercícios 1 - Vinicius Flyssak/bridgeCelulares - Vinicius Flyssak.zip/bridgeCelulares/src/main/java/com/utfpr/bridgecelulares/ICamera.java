package com.utfpr.bridgecelulares;

public interface ICamera {
    void tirarFotoFrontal();
    void tirarFotoTraseira();    
}
