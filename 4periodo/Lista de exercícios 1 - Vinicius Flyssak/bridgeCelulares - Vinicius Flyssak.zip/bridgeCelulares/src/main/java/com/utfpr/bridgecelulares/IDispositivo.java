package com.utfpr.bridgecelulares;

public interface IDispositivo {
    void configuraCelular();
}
