package com.utfpr.adaptersobremesas;

public class Bolo extends Sobremesa {
    public Bolo() {
        valor = 20;
    }
}
    
