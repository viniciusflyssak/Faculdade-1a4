package com.utfpr.adaptersobremesas;

public class Pudim extends Sobremesa {
    public Pudim() {
        valor = 15;
    }
}
    
