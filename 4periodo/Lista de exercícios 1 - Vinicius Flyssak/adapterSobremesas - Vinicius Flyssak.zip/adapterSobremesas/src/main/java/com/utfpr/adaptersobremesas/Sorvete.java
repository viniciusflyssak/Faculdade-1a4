package com.utfpr.adaptersobremesas;

public class Sorvete extends Sobremesa {
    public Sorvete() {
        valor = 10;
    }
}
    
