package com.utfpr.strategyjogo;

public class EstrategiaJoystick implements IInteracao{

    @Override
    public void mover() {
        System.out.println("Personagem corre na direção indicada pelo controle.");
    }
    
}
