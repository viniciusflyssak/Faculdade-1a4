package com.utfpr.strategyjogo;

public class EstrategiaGesto implements IInteracao{

    @Override
    public void mover() {
        System.out.println("Personagem dá um salto a frente sempre que um determinado gesto é realizado.");
    }
    
}