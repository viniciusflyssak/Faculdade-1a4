package com.utfpr.strategyjogo;

public class EstrategiaTeclado implements IInteracao{

    @Override
    public void mover() {
        System.out.println("Personagem move-se passo a passo toda vez que um dos botões de seta são pressionados.");
    }
    
}
