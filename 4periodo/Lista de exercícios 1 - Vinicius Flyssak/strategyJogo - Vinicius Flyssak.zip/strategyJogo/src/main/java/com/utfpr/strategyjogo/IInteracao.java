package com.utfpr.strategyjogo;

public interface IInteracao {
    void mover();
}
