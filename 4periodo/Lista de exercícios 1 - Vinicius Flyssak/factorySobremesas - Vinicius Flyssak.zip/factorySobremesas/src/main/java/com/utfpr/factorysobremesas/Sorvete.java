package com.utfpr.factorysobremesas;

public class Sorvete extends Sobremesa {
    public Sorvete() {
        valor = 10;
    }
}
    
