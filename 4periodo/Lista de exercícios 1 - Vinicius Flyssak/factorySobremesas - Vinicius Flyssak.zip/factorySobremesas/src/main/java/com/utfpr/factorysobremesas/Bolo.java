package com.utfpr.factorysobremesas;

public class Bolo extends Sobremesa {
    public Bolo() {
        valor = 20;
    }
}
    
