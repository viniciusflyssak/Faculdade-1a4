package com.utfpr.factorysobremesas;

public class Sobremesa {
    protected double valor;

    public double getValor() {
        return valor;
    }
    
    
}
