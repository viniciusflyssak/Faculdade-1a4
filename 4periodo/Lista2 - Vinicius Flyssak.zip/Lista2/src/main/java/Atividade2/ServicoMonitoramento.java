/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Atividade2;

/**
 *
 * @author vinic
 */
public class ServicoMonitoramento extends Servico {

    @Override
    public String getDescricao() {
        return "Monitora a satisfação do cliente no processo de aquisição do "
                + "produto, desde a realização do pedido até o recebimento.";
    }
}
