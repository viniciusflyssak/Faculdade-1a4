/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Atividade2;

/**
 *
 * @author vinic
 */
public class ServicoEntrega extends Servico {

    @Override
    public String getDescricao() {
        return "Conecta com o serviço de remessa externo para enviar o produto para "
                + "o cliente.";
    }
}
