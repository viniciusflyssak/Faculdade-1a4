package com.utfpr.jogoxadrez;

public interface Jogada {
    void moverPeca(String nomeJogador, String peca);
}
