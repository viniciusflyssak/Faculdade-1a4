package com.utfpr.jogoxadrezfactory;

public interface Jogada {
    void moverPeca(String nomeJogador, String peca);
}
