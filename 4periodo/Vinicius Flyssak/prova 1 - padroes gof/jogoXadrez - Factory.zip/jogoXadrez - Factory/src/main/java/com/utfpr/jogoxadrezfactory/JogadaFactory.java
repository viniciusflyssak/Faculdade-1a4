package com.utfpr.jogoxadrezfactory;

public abstract class JogadaFactory {
    protected abstract Jogada createJogada(String jogada);
}
