package com.utfpr.jogoxadrezadapter;

public class EstrategiaCheque {
    public void executaCheque(String nomeJogador, String peca) {
        System.out.println("Jogador " + nomeJogador + " realiza jogada de que deixa o oponente com o rei em extremo perigo usando"
                + " a peça " + '"' + peca + '"');
    }
}
