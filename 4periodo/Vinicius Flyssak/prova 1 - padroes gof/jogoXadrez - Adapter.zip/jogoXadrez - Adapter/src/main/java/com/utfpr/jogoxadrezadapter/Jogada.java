package com.utfpr.jogoxadrezadapter;

public interface Jogada {
    void moverPeca(String nomeJogador, String peca);
}
