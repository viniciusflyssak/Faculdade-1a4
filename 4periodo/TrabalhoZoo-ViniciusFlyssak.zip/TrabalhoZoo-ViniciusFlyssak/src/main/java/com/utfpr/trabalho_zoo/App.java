package com.utfpr.trabalho_zoo;

import com.utfpr.trabalho_zoo.model.Animal;
import com.utfpr.trabalho_zoo.model.Funcionario;
import com.utfpr.trabalho_zoo.model.Servico;
import com.utfpr.trabalho_zoo.repositorys.AnimalRepository;
import com.utfpr.trabalho_zoo.repositorys.FuncionarioRepository;
import com.utfpr.trabalho_zoo.repositorys.ServicoRepository;
import java.sql.*;
import java.util.List;
import java.util.Scanner;

public class App {

    public static void cadastrarAnimal() {
        Scanner scanner = new Scanner(System.in);
        Animal animal = new Animal();
        System.out.println("Digite o nome do animal:");
        animal.setNome(scanner.nextLine());
        System.out.println("Digite o nome científico do animal:");
        animal.setNomeCientifico(scanner.nextLine());
        System.out.println("Digite a família do animal:");
        animal.setFamilia(scanner.nextLine());
        System.out.println("Digite a espécie do animal:");
        animal.setEspecie(scanner.nextLine());
        System.out.println("Digite os comportamentos do animal:");
        animal.setComportamentos(scanner.nextLine());
        System.out.println("Digite o cuidador do animal(se não houver, digite 0):");
        animal.setProfissional(scanner.nextInt());
        AnimalRepository animalRepository = new AnimalRepository();
        animalRepository.salvar(animal);
        System.out.println("");
        System.out.println("");
        System.out.println("Animal cadastrado com sucesso!");
        System.out.println("");
        System.out.println("");
    }

    ;
    
    public static void cadastrarFuncionario() {
        Scanner scanner = new Scanner(System.in);
        Funcionario funcionario = new Funcionario();
        System.out.println("Digite o nome do funcionário:");
        funcionario.setNome(scanner.nextLine());
        System.out.println("Digite a profissão:");
        funcionario.setProfissao(scanner.nextLine());
        System.out.println("Digite o cpf do funcionário:");
        funcionario.setCpf(scanner.nextLine());
        System.out.println("Informe o sexo: ");
        funcionario.setSexo(scanner.nextLine());
        FuncionarioRepository funcionarioRepository = new FuncionarioRepository();
        funcionarioRepository.salvar(funcionario);
        System.out.println("");
        System.out.println("");
        System.out.println("Funcionário cadastrado com sucesso!");
        System.out.println("");
        System.out.println("");
    }

    ;
    
    public static void cadastrarServico() {
        Servico servico = new Servico();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o nome do Serviço:");
        servico.setNome(scanner.nextLine());
        System.out.println("Digite a descrição:");
        servico.setDescricao(scanner.nextLine());
        System.out.println("Digite a data e hora do serviço:");
        servico.setData(scanner.nextLine());
        System.out.println("Informe o código do profissional responsável:");
        servico.setProfissional(scanner.nextInt());
        System.out.println("Informe o código do animal:");
        servico.setAnimal(scanner.nextInt());
        servico.setConcluido(false);
        ServicoRepository servicoRepository = new ServicoRepository();
        servicoRepository.salvar(servico);
        System.out.println("");
        System.out.println("");
        System.out.println("Serviço cadastrado com sucesso!");
        System.out.println("");
        System.out.println("");
    }

    ;
    
    public static void listarServicos(boolean pendente) {
        ServicoRepository servicoRepository = new ServicoRepository();
        List<Servico> listaServicos;
        if (pendente){
            listaServicos = servicoRepository.listarTodosPendentes();    
        }else{
            listaServicos = servicoRepository.listarTodos();    
        }
        
        if (listaServicos.isEmpty()) {
            System.out.println("Nenhum serviço cadastrado!");
            return;
        }
        listaServicos.forEach((servico) -> {
            System.out.println("");
            System.out.println("");
            System.out.println("Código: " + servico.getId());
            System.out.println("Nome: " + servico.getNome());
            System.out.println("Descrição: " + servico.getDescricao());
            System.out.println("Data: " + servico.getData());
            System.out.println("Código profissional: " + servico.getProfissional());
            System.out.println("Código animal: " + servico.getAnimal());
            System.out.println("Concluído: " + servico.isConcluido());
        });
        System.out.println("");
        System.out.println("");
    }

    ;
    
    public static void listarAnimais() {
        AnimalRepository animalRepository = new AnimalRepository();
        List<Animal> listaAnimais = animalRepository.listarTodos();
        if (listaAnimais.isEmpty()) {
            System.out.println("Nenhum animal cadastrado!");
            return;
        }
        listaAnimais.forEach((animal) -> {
            System.out.println("");
            System.out.println("");
            System.out.println("Código: " + animal.getId());
            System.out.println("Nome: " + animal.getNome());
            System.out.println("Nome científico: " + animal.getNomeCientifico());
            System.out.println("Família: " + animal.getFamilia());
            System.out.println("Espécie: " + animal.getEspecie());
            System.out.println("Comportamentos: " + animal.getComportamentos());
            System.out.println("Profissional: " + animal.getProfissional());
        });
        System.out.println("");
        System.out.println("");
    }

    ;
        
    public static void listarFuncionarios() {
        FuncionarioRepository funcionarioRepository = new FuncionarioRepository();
        List<Funcionario> listaFuncionarios = funcionarioRepository.listarTodos();
        if (listaFuncionarios.isEmpty()) {
            System.out.println("Nenhum funcionário cadastrado!");
            return;
        }
        listaFuncionarios.forEach((funcionario) -> {
            System.out.println("");
            System.out.println("");
            System.out.println("Código: " + funcionario.getId());
            System.out.println("Nome: " + funcionario.getNome());
            System.out.println("Profissão: " + funcionario.getProfissao());
            System.out.println("Sexo: " + funcionario.getSexo());
            System.out.println("CPF: " + funcionario.getCpf());
        });
        System.out.println("");
        System.out.println("");
    }

    ;
    
    public static void consultarServico() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o código do serviço:");
        int codigo = scanner.nextInt();
        ServicoRepository servicoRepository = new ServicoRepository();
        Servico servico = servicoRepository.buscarServico(codigo);
        if (servico == null) {
            System.out.println("");
            System.out.println("");
            System.out.println("Serviço não encontrado!");
            System.out.println("");
            System.out.println("");
            return;
        }
        System.out.println("");
        System.out.println("");
        System.out.println("Código: " + servico.getId());
        System.out.println("Nome: " + servico.getNome());
        System.out.println("Descrição: " + servico.getDescricao());
        System.out.println("Data: " + servico.getData());
        System.out.println("Código profissional: " + servico.getProfissional());
        System.out.println("Código animal: " + servico.getAnimal());
        System.out.println("Concluído: " + servico.isConcluido());
        System.out.println("");
        System.out.println("");
    }

    ;
    
    public static void consultaProfissional() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o código do funcionário: ");
        int codigo = scanner.nextInt();
        FuncionarioRepository funcionarioRepository = new FuncionarioRepository();
        Funcionario funcionario = funcionarioRepository.buscarFuncionario(codigo);
        if (funcionario == null) {
            System.out.println("");
            System.out.println("");
            System.out.println("Funcionário não encontrado!");
            System.out.println("");
            System.out.println("");
            return;
        }
        System.out.println("");
        System.out.println("");
        System.out.println("Código: " + funcionario.getId());
        System.out.println("Nome: " + funcionario.getNome());
        System.out.println("Profissão: " + funcionario.getProfissao());
        System.out.println("Sexo: " + funcionario.getSexo());
        System.out.println("CPF: " + funcionario.getCpf());
        System.out.println("");
        System.out.println("");
    }

    ;
    
    public static void consultaAnimal() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o código do animal: ");
        int codigo = scanner.nextInt();
        AnimalRepository animalRepository = new AnimalRepository();
        Animal animal = animalRepository.buscarAnimal(codigo);
        if (animal == null) {
            System.out.println("");
            System.out.println("");
            System.out.println("Animal não encontrado!");
            System.out.println("");
            System.out.println("");
            return;
        }
        System.out.println("");
        System.out.println("");
        System.out.println("Código: " + animal.getId());
        System.out.println("Nome: " + animal.getNome());
        System.out.println("Nome científico: " + animal.getNomeCientifico());
        System.out.println("Família: " + animal.getFamilia());
        System.out.println("Espécie: " + animal.getEspecie());
        System.out.println("Comportamentos: " + animal.getComportamentos());
        System.out.println("Profissional: " + animal.getProfissional());
        System.out.println("");
        System.out.println("");
    }

    public static void apagarAnimal() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o código do animal: ");
        int codigo = scanner.nextInt();
        AnimalRepository animalRepository = new AnimalRepository();
        Animal animal = animalRepository.excluirAnimal(codigo);
        if (animal == null) {
            System.out.println("");
            System.out.println("");
            System.out.println("Animal não encontrado!");
            System.out.println("");
            System.out.println("");
            return;
        }
        System.out.println("");
        System.out.println("");
        System.out.println("Animal " + animal.getNome() + " excluído com sucesso!");
        System.out.println("");
        System.out.println("");
    }

    public static void apagarProfissional() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o código do funcionário: ");
        int codigo = scanner.nextInt();
        FuncionarioRepository funcionarioRepository = new FuncionarioRepository();
        Funcionario funcionario = funcionarioRepository.excluirFuncionario(codigo);
        if (funcionario == null) {
            System.out.println("");
            System.out.println("");
            System.out.println("Funcionário não encontrado!");
            System.out.println("");
            System.out.println("");
            return;
        }
        System.out.println("");
        System.out.println("");
        System.out.println("Funcionário " + funcionario.getNome() + " excluído com sucesso!");
        System.out.println("");
        System.out.println("");
    }

    public static void apagarServico() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o código do serviço:");
        int codigo = scanner.nextInt();
        ServicoRepository servicoRepository = new ServicoRepository();
        Servico servico = servicoRepository.excluirServico(codigo);
        if (servico == null) {
            System.out.println("");
            System.out.println("");
            System.out.println("Serviço não encontrado!");
            System.out.println("");
            System.out.println("");
            return;
        }
        System.out.println("");
        System.out.println("");
        System.out.println("Serviço " + servico.getNome() + " excluído com sucesso!");
        System.out.println("");
        System.out.println("");
    }

    public static void editarAnimal() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o código do animal: ");
        int codigo = scanner.nextInt();
        AnimalRepository animalRepository = new AnimalRepository();
        Animal animal = animalRepository.buscarAnimal(codigo);
        if (animal == null) {
            System.out.println("");
            System.out.println("");
            System.out.println("Animal não encontrado!");
            System.out.println("");
            System.out.println("");
            return;
        }
        Animal animalTemp = new Animal();
        System.out.println("Digite o nome do animal ou enter se deseja manter o atual:");
        animalTemp.setNome(scanner.nextLine());
        animalTemp.setNome(scanner.nextLine());
        System.out.println("Digite o nome científico do animal ou enter se deseja manter o atual:");
        animalTemp.setNomeCientifico(scanner.nextLine());
        System.out.println("Digite a família do animal ou enter se deseja manter o atual:");
        animalTemp.setFamilia(scanner.nextLine());
        System.out.println("Digite a espécie do animal ou enter se deseja manter o atual:");
        animalTemp.setEspecie(scanner.nextLine());
        System.out.println("Digite os comportamentos do animal ou enter se deseja manter o atual:");
        animalTemp.setComportamentos(scanner.nextLine());
        System.out.println("Digite o cuidador do animal(se não houver, digite 0) ou -1 se deseja manter o atual:");
        animalTemp.setProfissional(scanner.nextInt());

        if (!"".equals(animalTemp.getNome())) {
            animal.setNome(animalTemp.getNome());
        }
        if (!"".equals(animalTemp.getNomeCientifico())) {
            animal.setNomeCientifico(animalTemp.getNomeCientifico());
        }
        if (!"".equals(animalTemp.getFamilia())) {
            animal.setFamilia(animalTemp.getFamilia());
        }
        if (!"".equals(animalTemp.getEspecie())) {
            animal.setEspecie(animalTemp.getEspecie());
        }
        if (!"".equals(animalTemp.getComportamentos())) {
            animal.setComportamentos(animalTemp.getComportamentos());
        }
        if (animalTemp.getProfissional() != -1) {
            animal.setProfissional(animalTemp.getProfissional());
        }

        animalRepository.salvarEdicao(animal);
        System.out.println("");
        System.out.println("");
        System.out.println("Animal editado com sucesso!");
        System.out.println("");
        System.out.println("");
    }

    public static void editarFuncionario() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o código do funcionario: ");
        int codigo = scanner.nextInt();
        FuncionarioRepository funcionarioRepository = new FuncionarioRepository();
        Funcionario funcionario = funcionarioRepository.buscarFuncionario(codigo);
        if (funcionario == null) {
            System.out.println("");
            System.out.println("");
            System.out.println("Funcionário não encontrado!");
            System.out.println("");
            System.out.println("");
            return;
        }
        Funcionario funcionarioTemp = new Funcionario();
        System.out.println("Digite o nome do funcionário ou pressione enter se deseja manter:");
        funcionarioTemp.setNome(scanner.nextLine());
        funcionarioTemp.setNome(scanner.nextLine());
        System.out.println("Digite a profissão ou pressione enter se deseja manter:");
        funcionarioTemp.setProfissao(scanner.nextLine());
        System.out.println("Digite o cpf do funcionário ou pressione enter se deseja manter:");
        funcionarioTemp.setCpf(scanner.nextLine());
        System.out.println("Informe o sexo ou pressione enter se deseja manter: ");
        funcionarioTemp.setSexo(scanner.nextLine());

        if (!"".equals(funcionarioTemp.getNome())) {
            funcionario.setNome(funcionarioTemp.getNome());
        }
        if (!"".equals(funcionarioTemp.getProfissao())) {
            funcionario.setProfissao(funcionarioTemp.getProfissao());
        }
        if (!"".equals(funcionarioTemp.getCpf())) {
            funcionario.setCpf(funcionarioTemp.getCpf());
        }
        if (!"".equals(funcionarioTemp.getSexo())) {
            funcionario.setSexo(funcionarioTemp.getSexo());
        }

        funcionarioRepository.salvarEdicao(funcionario);
        System.out.println("");
        System.out.println("");
        System.out.println("Funcionário editado com sucesso!");
        System.out.println("");
        System.out.println("");
    }

    public static void editarServico() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o código do servico: ");
        int codigo = scanner.nextInt();
        ServicoRepository servicoRepository = new ServicoRepository();
        Servico servico = servicoRepository.buscarServico(codigo);
        if (servico == null) {
            System.out.println("");
            System.out.println("");
            System.out.println("Serviço não encontrado!");
            System.out.println("");
            System.out.println("");
            return;
        }
        Servico servicoTemp = new Servico();
        System.out.println("Digite o nome do Serviço ou pressione enter para manter:");
        servicoTemp.setNome(scanner.nextLine());
        servicoTemp.setNome(scanner.nextLine());
        System.out.println("Digite a descrição ou pressione enter para manter:");
        servicoTemp.setDescricao(scanner.nextLine());
        System.out.println("Digite a data e hora do serviço ou pressione enter para manter:");
        servicoTemp.setData(scanner.nextLine());
        System.out.println("Informe o código do profissional responsável ou -1 para manter:");
        servicoTemp.setProfissional(scanner.nextInt());
        System.out.println("Informe o código do animal ou -1 para manter:");
        servicoTemp.setAnimal(scanner.nextInt());
        scanner.nextLine();
        System.out.println("Concluído? S para Sim, N para Não:");
        String concluido = scanner.nextLine();
        if ("S".equals(concluido)){
            servico.setConcluido(true);
        }else{
            servico.setConcluido(false);
        }

        if (!"".equals(servicoTemp.getNome())) {
            servico.setNome(servicoTemp.getNome());
        }
        if (!"".equals(servicoTemp.getDescricao())) {
            servico.setDescricao(servicoTemp.getDescricao());
        }
        if (!"".equals(servicoTemp.getData())) {
            servico.setData(servicoTemp.getData());
        }
        if (servicoTemp.getProfissional() != -1) {
            servico.setProfissional(servicoTemp.getProfissional());
        }
        if (servicoTemp.getAnimal()!= -1) {
            servico.setAnimal(servicoTemp.getProfissional());
        }
        servicoRepository.salvarEdicao(servico);
        System.out.println("");
        System.out.println("");
        System.out.println("Serviço editado com sucesso!");
        System.out.println("");
        System.out.println("");
    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        //variáveis de conexão    

        int opcao = -1;
        Scanner scanner = new Scanner(System.in);

        while (opcao != 0) {
            System.out.println("Bem vindo ao gerenciador de zoológicos 2000!");
            System.out.println("Selecione a opção desejada:");
            System.out.println("0 - Sair");
            System.out.println("1 - Cadastrar funcionário");
            System.out.println("2 - Cadastrar animal");
            System.out.println("3 - Cadastrar serviço");
            System.out.println("4 - Consultar animais");
            System.out.println("5 - Consultar funcionários");
            System.out.println("6 - Consultar serviços");
            System.out.println("7 - Listar animais");
            System.out.println("8 - Listar funcionários");
            System.out.println("9 - Listar serviços");
            System.out.println("10 - Apagar animal");
            System.out.println("11 - Apagar funcionário");
            System.out.println("12 - Apagar serviço");
            System.out.println("13 - Editar animal");
            System.out.println("14 - Editar funcionário");
            System.out.println("15 - Editar serviço");
            System.out.println("16 - Listar serviços pendentes");
            opcao = scanner.nextInt();
            switch (opcao) {
                case 1 ->
                    cadastrarFuncionario();
                case 2 ->
                    cadastrarAnimal();
                case 3 ->
                    cadastrarServico();
                case 4 ->
                    consultaAnimal();
                case 5 ->
                    consultaProfissional();
                case 6 ->
                    consultarServico();
                case 7 ->
                    listarAnimais();
                case 8 ->
                    listarFuncionarios();
                case 9 ->
                    listarServicos(false);
                case 10 ->
                    apagarAnimal();
                case 11 ->
                    apagarProfissional();
                case 12 ->
                    apagarServico();
                case 13 ->
                    editarAnimal();
                case 14 ->
                    editarFuncionario();
                case 15 ->
                    editarServico();
                case 16 ->
                    listarServicos(true);
            }
        }
    }
}
